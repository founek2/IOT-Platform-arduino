#include <ESP8266HTTPClient.h>
#include <WiFiClientSecure.h> 

// const char fingerprint[] PROGMEM = "20 86 B4 07 98 9F 38 D4 C6 F9 DF CA 00 40 5E E3 10 48 D3 88";

class Plat
{
public:
	Plat(const char *api_key) : m_API_KEY(api_key), m_host("iotplatforma.cloud"), m_port(443) {
	}
	int sendData(const double val)
	{
		http.begin("http://iotplatforma.cloud/saveSensorData"); //Specify request destination
		http.addHeader("Content-Type", "application/json");
		int httpCode = http.POST("{\"data\": {\"Teplota\": { \"value\": " + String(val) + ", \"unit\": \"°C\"}, \"apiKey\": \"" + m_API_KEY + "\"}"); //Send the request
		Serial.println("{\"data\": {\"Teplota\": { \"value\": " + String(val) + ", \"unit\": \"°C\"}}, \"apiKey\": \"" + m_API_KEY + "\"}");
		http.end();
		return httpCode;
	}

	int sendDataHTTPS(const double val)
	{
		WiFiClientSecure httpsClient;
		// httpsClient.setFingerprint(fingerprint);
		httpsClient.setInsecure();
		httpsClient.setTimeout(15000); // 15 Seconds

		String getData, Link;

		int r=0; //retry counter
		while((!httpsClient.connect(m_host, m_port)) && (r < 30)){
			delay(100);
			Serial.print(".");
			r++;
		}
		if(r==30) {
			Serial.println("Connection failed");
			return -1;
		}
		else {
			Serial.println("Connected to web");
		}
		  
  		//POST Data
  		Link = "/saveSensorData";

		String body = "{\"data\": {\"Teplota\": { \"value\": " + String(val) + ", \"unit\": \"°C\"}}, \"apiKey\": \"" + m_API_KEY + "\"}";
		httpsClient.print(String("POST ") + Link + " HTTP/1.1\r\n" +
               "Host: " + m_host + "\r\n" +
               "Content-Type: application/json"+ "\r\n" +
               "Content-Length: " + body.length() + "\r\n\r\n" +
               body);
 
  		Serial.println("request sent");

		while (httpsClient.connected()) {
    			String line = httpsClient.readStringUntil('\n');
    			if (line == "\r") {
      			Serial.println("headers received");
      			break;
    			}
  		}

		Serial.println("reply was:");
		Serial.println("==========");
		String line;
		while(httpsClient.available()){        
			line = httpsClient.readStringUntil('\n');  //Read Line by Line
			if(line == "{\"status\":\"success\"}"){ //Print response
				// httpsClient.flush();
				return 200;
			}
		}
		
		return 500;
	}

private:
	HTTPClient http; //Declare object of class HTTPClient
	String m_API_KEY;
	const char * m_host;
	const int m_port;
};